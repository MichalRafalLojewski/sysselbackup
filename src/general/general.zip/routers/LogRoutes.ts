import LogController from "../controllers/LogController";

export default class LogRoutes {

    constructor(app, logController: LogController) {
        app.get("/logs",
        logController.getLogs.bind(logController));
    }
}